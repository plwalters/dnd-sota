define([], function () {
	var home = {
		activate: activate
	};
	return home;

	function activate() {
		console.log('About activated');
	} 
});